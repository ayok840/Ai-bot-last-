import os
from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse
from google import genai

app = Flask(__name__)

GEMINI_API_KEY = "AQ.Ab8RN6LnwZd2Uon-DXaMzk-qkFp97aQS3dg60cwr9PeionwCfQ"
ai_client = genai.Client(api_key=GEMINI_API_KEY)

@app.route("/", methods=['GET'])
def home():
    return "Bot WA Ujian Ready!", 200

@app.route("/whatsapp", methods=['POST'])
def whatsapp_bot():
    incoming_msg = request.values.get('Body', '').strip()
    prompt = f"Kamu adalah asisten ujian otomatis yang pintar. Tolong jawab soal berikut dengan benar, ringkas, dan jelas:\n\n{incoming_msg}"
    
    resp = MessagingResponse()
    msg = resp.message()
    
    try:
        response = ai_client.models.generate_content(
            model='gemini-2.5-flash',
            contents=prompt,
        )
        msg.body(response.text)
    except Exception as e:
        msg.body("Sistem AI sibuk, coba kirim ulang ya!")
        
    return str(resp)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)
